package com.techyourchance.dagger2course

object Constants {
    const val BASE_URL = "https://api.stackexchange.com/2.2/"
    const val STACKOVERFLOW_API_KEY = "ZiXCZbWaOwnDgpVT9Hx8IA(("
}