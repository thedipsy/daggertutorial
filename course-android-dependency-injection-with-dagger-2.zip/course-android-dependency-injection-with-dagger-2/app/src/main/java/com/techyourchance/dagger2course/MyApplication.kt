package com.techyourchance.dagger2course

import android.app.Application

class MyApplication: Application() {

    override fun onCreate() {
        super.onCreate()
    }

}