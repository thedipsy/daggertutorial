package com.techyourchance.dagger2course.screens.common

import androidx.fragment.app.FragmentManager
import com.techyourchance.dagger2course.screens.common.dialogs.ServerErrorDialogFragment

class DialogsNavigator(private val fragmentManager: FragmentManager) {

    fun showServerErrorDialog() =
        fragmentManager.beginTransaction()
            .add(ServerErrorDialogFragment.newInstance(), null)
            .commitAllowingStateLoss()
}